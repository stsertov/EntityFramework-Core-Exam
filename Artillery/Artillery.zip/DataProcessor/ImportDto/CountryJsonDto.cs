﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Artillery.DataProcessor.ImportDto
{
    public class CountryJsonDto
    {
        public int Id { get; set; }
    }
}
