﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-FH98M39\SQLEXPRESS01;Database=Artillery;Trusted_Connection=True";
    }
}
